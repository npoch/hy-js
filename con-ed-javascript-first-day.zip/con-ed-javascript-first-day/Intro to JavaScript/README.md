# Intro to JavaScript

### Overview

This module will cover the following topics:
* [What is JavaScript](what-is-javascript.md)
* [How to run JavaScript Code](how-to-run-javascript-code.md)

### Exercises
1. <a href="https://hychalknotes.s3.amazonaws.com/linking-external-files--conEd.zip" download>linking-external-files</a>

### Answers
1. <a href="https://hychalknotes.s3.amazonaws.com/linking-external-files%20-ANSWER--conEd.zip"
	download>linking-external-files-ANSWER</a>