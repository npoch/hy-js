---
name: Content Change / Flow Modification
about: 'Priority 1 - Including errors and necessary updates to content, as well as
  areas that disrupt teaching flow. '
title: "[P1]"
labels: ''
assignees: mgoldber

---

* **Name of file(s) that requires changes**

* **Please summarize the change that is being requested**

* **What is the motivation / use case for changing the content in this way?**

* **Additional information**
