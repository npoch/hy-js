---
name: Typos / Minor Notes
about: Priority 2 - Including any typos that have been located or any issues that
  don't disrupt overall experience
title: "[P2]"
labels: ''
assignees: mgoldber

---

* **Name of file(s) that requires changes**

* **Please summarize the change that is being requested**

* **Additional information**
