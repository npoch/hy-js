$(function() {
    console.log('ready');
});