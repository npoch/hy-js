$(document).ready(function() {
    // Using jQuery
    /*
        1. Select the elements in the comments and save it in a variable
        2. Log each jQuery object to the console
    */

    // EXAMPLE:
    // the body
    const $body = $('body');
    console.log("body: ", $body);

    // all paragraphs

    // log how many paragraphs there are on the page

    // all the links in the nav

    // all 6 features in the features section

    // the feature section and the contact section (using 1 selector)

    // the email input (using attribute selector)

    // the checked radio input (using attribute selector)

    // the submit input (using attribute selector)

}); // end of document ready